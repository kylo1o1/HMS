

import { createSelector } from 'reselect';

const selectAdminAppointmentData = (state) => state.adminAppointmentData;
const selectPatientData = (state) => state.patientData;
const selectDoctors = (state) => state?.dataSL;

export const selectAdminHomeData = createSelector(
  [selectAdminAppointmentData, selectPatientData,selectDoctors],
  (adminAppointmentData, patientData,dataSL) => ({
    completedAppointments: adminAppointmentData?.appData?.completedApps ?? "",
    noOfPatients: patientData?.noOfPatients ?? "",
    patients:patientData?.patients,
    doctors:dataSL?.doctors ??"",
    noOfDoctor:dataSL?.noOfDoctor ?? ""
    
  })
);
