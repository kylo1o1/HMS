import { createSlice } from '@reduxjs/toolkit';
import { resetCartState } from './cartSlice';
import { resetDoctorListState } from './dataSlice';


const authSlice = createSlice({
    name: 'auth',
    initialState: {
        user: [],
        isAuthenticated: false,
        loading: false,
        error: null
    },
    reducers: {
        loginStart: (state) => {
            state.loading = true;
            state.error = null;
        },
        loginSuccess: (state, action) => {
            state.user = action.payload.user;
            state.isAuthenticated = true;
            sessionStorage.setItem("user", JSON.stringify(action.payload.user));  
            state.loading = false;
        },
        loginFailure: (state, action) => {
            state.error = action.payload;
            state.loading = false;
        },
        logout: (state) => {
            state.user = null;
            state.token = null;
            state.isAuthenticated = false;
            console.log(state.user);
            
            sessionStorage.removeItem("user");
        }
    }
});

export const { loginStart, loginSuccess, loginFailure, logout } = authSlice.actions;
export default authSlice.reducer;
