


const initialState = {
    processing:false,
    totalRevenue:null,
    appointmentRevenue:null,
    
}