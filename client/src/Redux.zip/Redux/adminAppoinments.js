import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  appLoading: false,
  appData: {
    appointments: [],
    completedApps: null,
  },
  error: "",
};

const adminAppointmentSlice = createSlice({
  name: "appointments",
  initialState,
  reducers: {
    appLoading: (state) => {
      state.appLoading = true;
      state.error = null;
    },
    appFetchSuccess: (state, action) => {
      state.appData.appointments = action.payload.appointments;
      state.appLoading = false;
      state.appData.completedApps = action.payload.completed;
    },
    appFetchFailure: (state, action) => {
      state.appLoading = false;
      state.error = action.payload;
    },
  },
});

export const { appLoading, appFetchSuccess, appFetchFailure } = adminAppointmentSlice.actions;
export default adminAppointmentSlice.reducer;
