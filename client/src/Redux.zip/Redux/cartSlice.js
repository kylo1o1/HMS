import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  cart: {
    userId: null,
    medicines: [],
    totalPrice: 0,
  },
  error: null,
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    cartRequest(state) {
      state.loading = true;
      state.error = null;
    },
    cartSuccess(state, action) {
      state.loading = false;
      state.cart = action.payload;
      state.error = null;
    },
    cartFail(state, action) {
      state.loading = false;
      state.error = action.payload;
    },
    addItemToCart(state, action) {
      state.cart.medicines.unshift(action.payload);
      state.cart.totalPrice = state.cart.medicines.reduce((sum, item) => sum + item.itemTotal, 0);
    },
    removeItemFromCart(state, action) {
      state.cart.medicines = state.cart.medicines.filter(
        (item) => item.medicineId._id !== action.payload.medicineId
      );
      state.cart.totalPrice = state.cart.medicines.reduce((sum, item) => sum + item.itemTotal, 0);
    },
    updateItemQuantity(state, action) {
      const { medicineId, quantity, amount } = action.payload;
      const itemIndex = state.cart.medicines.findIndex(item => item.medicineId._id === medicineId);

      if (itemIndex !== -1) {
        if (quantity <= 0) {
          state.cart.medicines.splice(itemIndex, 1);
        } else {
          state.cart.medicines[itemIndex].quantity = quantity;
          state.cart.medicines[itemIndex].itemTotal = quantity * amount;
        }
      }
      state.cart.totalPrice = state.cart.medicines.reduce((sum, item) => sum + item.itemTotal, 0);
    },
    clearCart(state) {
      state.cart = { userId: state.cart.userId, medicines: [], totalPrice: 0 };
    },
    resetCartState: () => initialState, // Reset on logout
  },
});

export const {
  cartRequest,
  cartSuccess,
  cartFail,
  addItemToCart,
  removeItemFromCart,
  updateItemQuantity,
  clearCart,
  resetCartState,
} = cartSlice.actions;

export default cartSlice.reducer;
